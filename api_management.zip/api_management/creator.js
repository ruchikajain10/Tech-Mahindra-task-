const S = require('string');
const fs = require('fs');
//const database = require('./database.js');
var arr_invoke=[];
var arr_query=[];

function findIQ(value, index, array) {
  
  if(value.search(' ')>=0){
  }else if (value.search('query')>=0 || value.search('init')>=0){
    arr_query.push(value);
  }else{
    arr_invoke.push(value);
  }
}


exports.first=function(file_name){
fs.readFile(file_name, 'utf8', (err, data)=>{
  while(true){
    var ss= S(data).between("/*" , "*/");
    if(ss!=''){
      data=data.replace(ss['orig'],'');
      data=data.replace('/**/','');
    }else{
      break;
    }
  }

  var pos_si= data.indexOf('Invoke');
  var pos_s= data.indexOf('if ',pos_si);
  var pos_e= data.indexOf('func ',pos_s);
  var fdata1=data.slice(pos_s,pos_e);
  var arr=[];

  while(true){
    var ss1= S(fdata1).between('"','"');
    if(ss1!=''){
      arr.push(ss1['orig']);
      fdata1=fdata1.replace(ss1['orig'],'');
      fdata1=fdata1.replace('""','');
    }else{
      break;
    }
  }
  var uSet = new Set(arr);
  arr=[...uSet];
  arr.forEach(findIQ);
  dd1='//'+arr_query;
  fs.appendFileSync('query.js',dd1,(err)=>{
    if(err) console.error('Error occured in final appending');
  });
  fs.appendFileSync('invoke.js',"'use strict';"+'\n'+"const { FileSystemWallet, Gateway } = require('fabric-network');"+'\n'+"const path = require('path');"+'\n'+"const ccpPath = path.resolve(__dirname, '..', '..', 'first-network', 'connection-org1.json');"+'\n'+"async function invokeSDK(operation,decryptedData,res) {"+'\n'+ "try {"+'\n'+"// Create a new file system based wallet for managing identities."+'\n'+"const walletPath = path.join(process.cwd(), 'wallet');"+'\n'+"const wallet = new FileSystemWallet(walletPath);"+'\n'+"console.log(`Wallet path: ${walletPath}`);"+'\n'+"// Check to see if we've already enrolled the user."+'\n'+"const userExists = await wallet.exists('user1');"+'\n'+"if (!userExists) {"+'\n'+"console.log('An identity for the user \"user1\" does not exist in the wallet');"+'\n'+"console.log('Run the registerUser.js application before retrying');"+'\n'+"return;"+'\n'+"}"+'\n'+"// Create a new gateway for connecting to our peer node."+'\n'+"const gateway = new Gateway();"+'\n'+"await gateway.connect(ccpPath, { wallet, identity: 'user1', discovery: { enabled: true, asLocalhost: true } });"+'\n'+"// Get the network (channel) our contract is deployed to."+'\n'+"const network = await gateway.getNetwork('mychannel');"+'\n'+"// Get the contract from the network."+'\n'+"const contract = network.getContract('fabcar');"+'\n'+"// Submit the specified transaction."+'\n'+"await contract.submitTransaction(operation,decryptedData);"+'\n'+"console.log('Transaction has been submitted');"+'\n'+"// Disconnect from the gateway."+'\n'+"await gateway.disconnect();"+'\n'+"}catch (error) {"+'\n'+"console.error(`Failed to submit transaction: ${error}`);"+'\n'+"process.exit(1);"+'\n'+"}"+'\n'+"}"+'\n'+"invokeSDK();",(err)=>{
    if(err)
    console.error('Error occured in final appending');
  });
 // var re=database.insert(file_name,arr_query.join(','),arr_invoke.join(','));
//  console.log(re);
console.log(arr_invoke);
console.log(arr_query);

fs.appendFileSync('route.js', '// creating route file', function (err) {
        if (err) throw err;
        console.log('Saved!');
      });

    fs.appendFileSync('route.js','\n'+"var update = require('./invoke.js');"+'\n'+"var query = require('./query.js');", function (err) {
        if (err) throw err;
        console.log('Saved!');
      });

    for(i=0;i<arr_invoke.length;i++){
        fs.appendFileSync('route.js','\n'+"exports."+arr_invoke[i]+"= function (decryptedData,res){"+'\n'+"​​update.invokeSDK(\""+arr_invoke[i]+"\""+",decryptedData,res);"+'\n'+"}​", function (err) {
            if (err) throw err;
            console.log('Saved!');
          });
        }
    for(i=0;i<arr_query.length;i++){
        fs.appendFileSync('route.js','\n'+"exports."+arr_invoke[i]+"= function (decryptedData,res){"+'\n'+"​​query.querySDK(\""+arr_query[i]+"\""+",decryptedData,res);"+'\n'+"}​", function (err) {
            if (err) throw err;
            console.log('Saved!');
          });
        }

        fs.appendFileSync('app.js', '// creating app.js file', function (err) {
            if (err) throw err;
            console.log('Saved!');
          });
    
        fs.appendFileSync('app.js','\n'+"var express = require('express');"+"\nvar path = require('path');"+"\nvar logger = require('morgan');"+"\nvar bodyParser = require('body-parser'); //for fileupload"+"\nvar fs = require('fs'); //for fileupload"+"\nvar route = require('./route.js');"+"\nvar app = express()"+"\napp.use(bodyParser.json()); // to support JSON-encoded bodies"+"\napp.use(bodyParser.urlencoded({​​ // to support URL-encoded bodies"+"\nextended: true"+"\n }​​));", function (err) {
            if (err) throw err;
            console.log('Saved!');
          });
    
        for(i=0;i<arr_invoke.length;i++){
            fs.appendFileSync('app.js','\n'+"app.get('/org1/"+arr_invoke[i]+"',function(req,res,next) {"+"\n​​console.log(\""+arr_invoke[i]+" --- start\");"+"\nroute."+arr_invoke[i]+"(req,res);"+"\n​​console.log(\""+arr_invoke[i]+" --- end\");"+"\n}​​)", function (err) {
                if (err) throw err;
                console.log('Saved!');
              });
            }
        for(i=0;i<arr_query.length;i++){
            fs.appendFileSync('app.js','\n'+"app.get('/org1/"+arr_query[i]+"',function(req,res,next) {"+"\n​​console.log(\""+arr_query[i]+" --- start\");"+"\nroute."+arr_query[i]+"(req,res);"+"\n​​console.log(\""+arr_query[i]+" --- end\");"+"\n}​​)", function (err) {
                if (err) throw err;
                console.log('Saved!');
              });
            }
            
        fs.appendFileSync('app.js','\n'+"app.use(function(req, res, next) {​​"+"\nres.header(\"Access-Control-Allow-Origin\", \"*\");"+"\nres.header(\"Access-Control-Allow-Headers\", \"Origin, X-Requested-With, Content-Type, Accept\");"+"\nnext();"+"\n}​​);"+"\n/// catch 404 and forward to error handler"+"\napp.use(function(req, res, next) {​​"+"\nvar err = new Error('Not Found');"+"\nerr.status = 404;"+"\nnext(err);"+"\n}​​);"+"\n// production error handler"+"\n//no stacktraces leaked to user"+"\napp.use(function(err, req, res, next) {​​"+"\nres.status(err.status || 500);"+"\nres.render('error', {​​"+"\nmessage: err.message,"+"\nerror: {​​}​​,"+"\ntitle: 'error'"+"\n}​​);"+"\n}​​);"+"\napp.set('port', process.env.PORT || 3000);"+"\nvar server = app.listen(app.get('port'), function() {​​"+"\nconsole.log('Express server listening on port ' + server.address().port);"+"\n}​​);"+"\nmodule.exports = app;"+"\nSet MaxRetries = 3"+"\nSet MaxRestarts = 3"+"\nSet AbortOnError = True", function (err) {
            if (err) throw err;
            console.log('Saved!');
        });

 


});
};





