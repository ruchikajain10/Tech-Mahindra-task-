const lineReader = require('line-reader');
const S = require('string');
const fs = require('fs');
var arr=[];

exports.cleanline= function(file_name){
lineReader.eachLine(file_name, (line, last) => {
  line=S(line).trim().s;
    if (!(line.startsWith("//"))){
      arr.push(line);
      data= arr.join("\n");
      fs.writeFileSync(file_name,data,(err,d1)=>{
        if(err) console.error(err);
        console.log("cleaning done");
      });
    }
});
};
