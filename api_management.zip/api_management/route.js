// creating route file
var update = require('./invoke.js');
var query = require('./query.js');
exports.createCar= function (decryptedData,res){
​​update.invokeSDK("createCar",decryptedData,res);
}​
exports.changeCarOwner= function (decryptedData,res){
​​update.invokeSDK("changeCarOwner",decryptedData,res);
}​
exports.createCar= function (decryptedData,res){
​​query.querySDK("queryCar",decryptedData,res);
}​
exports.changeCarOwner= function (decryptedData,res){
​​query.querySDK("initLedger",decryptedData,res);
}​
exports.undefined= function (decryptedData,res){
​​query.querySDK("queryAllCars",decryptedData,res);
}​