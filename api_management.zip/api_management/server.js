//var Gen_schema = require('./Gen_schema.model.js');
//const mongoose = require('mongoose');
const creator = require('./creator.js');
//const updates = require('./updates.js');
const fs = require('fs');
const readlines = require('./readlines.js');
readlines.cleanline('fabcar.go');
//var url="mongodb+srv://mogo:practice@cluster0.dhjvr.mongodb.net/Files?retryWrites=true&w=majority";
//mongoose.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true  });
creator.first('fabcar.go');
/*Gen_schema.findOne({file_name:'marbles_chaincode.go'},(err,result)=>{
  if (err) console.error(err);
  if (result){
    fs.unlinkSync('invoke.js', (err)=>{
        if (err) console.error(err);
      });
      fs.unlinkSync('query.js',(err)=>{
        if (err) console.error(err);
      });
    updates.update('marbles_chaincode.go', result);
  }else{
    firsts.first('marbles_chaincode.go');
  }
});
*/
